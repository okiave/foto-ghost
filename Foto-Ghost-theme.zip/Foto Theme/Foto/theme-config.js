disqus_enabled = false;
disqus_shortname = "NAME";
sidebar_enabled = false;